
<h1>Ihre Registrierung hat geklappt!</h1>

Ihre Nummer ist {{$nummer}}.