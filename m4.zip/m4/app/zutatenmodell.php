<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class zutatenmodell extends Model
{
    //
}
