<!DOCTYPE html><html lang='de'>
<head>
    <meta charset='UTF-8'>
    <title>test</title>
    <link href='css/bootstrap.css' rel='stylesheet'>
    <link href='css/design.css' rel='stylesheet'>
</head>
<body>
<?php echo $__env->make('nav.navbaroben', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mt-4">
    <div class="row mt-2">
        <div class="col-12 float-md-none">

            <a><h2><?php echo e($anzahl); ?> Zutaten</h2></a>

</div>
</div>
<div class="border-dark border mt-4">
    <table class="table table-striped table-hover">

        <thead>
        <tr class="">
            <th scope="col" class="w-auto"><a class="m-1">Zutaten</a></th>
            <th scope="col" class="w-auto"><a class="m-1">Bio?</a></th>
            <th scope="col" class="w-auto"><a class="m-1">Vegan?</a></th>
            <th scope="col" class="w-auto"><a class="m-1">Vegetarisch?</a></th>
            <th scope="col" class="w-auto"><a class="m-1">Glutenfrei?</a></th>
        </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $zutaten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zutat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                <td>
                            <form action="http://www.google.de/search" target="_blank" method="get">
                            <input class="btn btn-link" type="submit" name="q"  value="<?php echo e($zutat->Name); ?>" data-toggle="tooltip" title="Suchen Sie nach '.htmlspecialchars($zutat['Name']).' im Web">
                            </form>
                            </td>
                <?php if($zutat->Bio): ?>
                        <td><img class="img symbol float-md-left ml-2" src="button/svgs/regular/check-circle.svg" alt="fehler"></td>
                <?php else: ?>
                        <td><img class="img symbol float-md-left ml-2" src="button/svgs/regular/circle.svg" alt="fehler"></td>
                <?php endif; ?>
                <?php if($zutat->Vegan): ?>
                        <td><img class="img symbol float-md-left ml-2" src="button/svgs/regular/check-circle.svg" alt="fehler"></td>
                        <?php else: ?>
                        <td><img class="img symbol float-md-left ml-2" src="button/svgs/regular/circle.svg" alt="fehler"></td>
                    <?php endif; ?>
                <?php if($zutat->Vegetarisch): ?>
                        <td><img class="img symbol float-md-left ml-2" src="button/svgs/regular/check-circle.svg" alt="fehler"></td>
                        <?php else: ?>
                        <td><img class="img symbol float-md-left ml-2" src="button/svgs/regular/circle.svg" alt="fehler"></td>
                    <?php endif; ?>
                <?php if($zutat->Glutenfrei): ?>
                        <td><img class="img symbol float-md-left ml-2" src="button/svgs/regular/check-circle.svg" alt="fehler"></td>
                        <?php else: ?>
                        <td><img class="img symbol float-md-left ml-2 regular" src="button/svgs/regular/circle.svg" alt="fehler"></td>
                    <?php endif; ?>
                </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

    </table>
</div>
</div>
<?php echo $__env->make('nav.navbarunten', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\DBWT\m4\resources\views/pages/zutaten.blade.php ENDPATH**/ ?>