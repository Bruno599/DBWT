<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Details.html</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/design.css" rel="stylesheet">

    <?php if($refresh): ?><meta http-equiv="refresh" content="0; URL=Produkte.php"><?php endif; ?>


</head>
<body>
<?php echo $__env->make('nav.navbaroben', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mt-4 mb-4">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-7 text-left">
                <h2>Details für "<?php echo e($mahlzeit['Name']); ?>"</h2>
            </div>
            <div class="col-2 text-right">
                <br><a class=""><?php if(isset($_SESSION['aktive'])): ?><?php echo e($_SESSION['role']); ?>-Preis</a> <?php else: ?> Gast-Preis</a> <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-3 mb-2 ">


                <?php echo $__env->make('pages.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
            <div class="col-7 p-2 pt-3" >
<?php if($mahlzeit['Binärdaten']): ?>
    <img class="img details_picture mw-100" alt="platzhalter" src="data:image/jpeg;base64, <?php echo e($mahlzeit['Binärdaten']); ?>">
<?php else: ?>
    <img class="img details_picture mw-100" src="pictures/platzhalter.jpg" alt="platzhalter">
<?php endif; ?>
            </div>
            <div class="col-2 p-2">
                <div class="row h-50 text-right">
                    <div class="col">
                    <h2><?php echo e($mahlzeit['Preis']); ?>€</h2>
                    </div>
                </div>
                <div class="row h-50 align-items-end">
                    <div class="col">
                        <button class="w-100 align-middle align-content-end p-0  text-center">
                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/utensils.svg" alt="platzhalter">
                            <i class="fas fa-utensils"></i>
                            Vorbestellen
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-3 mt-4 ">
                <a class="text-center">Melden Sie sich jetzt an, um die wirklich viel günstigeren Preis für Mitarbeiter oder Studenten zu sehen</a>
            </div>
            <div class="mt-3 col-7 pl-1 pr-1">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item ml-4">
                        <a class="nav-link active fh_color" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Beschreibung</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link fh_color" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Zutaten</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link fh_color" id="messages-tab" data-toggle="tab" href="#messages" role="tab" aria-controls="messages" aria-selected="false">Bewertung</a>
                    </li>
                    <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'Student'): ?>
                    <li class="nav-item">
                        <a class="nav-link fh_color" id="bewertung-tab" data-toggle="tab" href="#bewertung" role="tab" aria-controls="bewertung" aria-selected="false">Bewertung hinzufügen</a>
                    </li>
                    <?php endif; ?>
                </ul>

                <div class="tab-content" >
                    <div class="tab-pane active border-right border-left border-bottom tab_content_size p-2" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <?php echo e($mahlzeit['Beschreibung']); ?>

                    </div>
                    <div class="tab-pane border-right border-left border-bottom tab_content_size p-2" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <ul>
                            <?php $__currentLoopData = $zutaten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zutat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($zutat->Name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="tab-pane border-right border-left border-bottom tab_content_size p-2" id="messages" role="tabpanel" aria-labelledby="messages-tab"  >
                    <!--<iframe src="/Bewertung/" width="100%" height="500"><p>Fehler</p></iframe>-->
                        <?php if(!empty($bewertung)): ?>
                            <div class="col ml-3">
                                <div class="row mt-2">
                                    <div class="col-6">
                                    <p> Die durchschnittliche Bewertung bei <?php echo e($size); ?> Kommentaren liegt bei: <?php echo e($durchschnitt); ?></p>
                                    </div>
                                    <div class="col-6">
                                        <?php if($durchschnitt >= 0 && $durchschnitt <= 0.4): ?>
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                        <?php elseif($durchschnitt >= 0.5 && $durchschnitt <= 1.4): ?>
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                        <?php elseif($durchschnitt >= 1.5 && $durchschnitt <= 2.4): ?>
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                        <?php elseif($durchschnitt >= 2.5 && $durchschnitt <= 3.4): ?>
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                        <?php elseif($durchschnitt >= 3.5 && $durchschnitt <= 4.4): ?>
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                        <?php else: ?>
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                            <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                        <?php endif; ?>
                                    </div>
                            </div>

                        <?php $__currentLoopData = $bewertung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="row w-100 border border-dark mt-1 mb-1">
                                <div class="col">
                                    <div class="row w-100 ml-2 mt-2">
                                        <div class="col m-2">
                                            Benutzer:<br><?php echo e($bew->Nutzername); ?>

                                        </div>
                                        <div class="col m-2">
                                            <?php switch($bew->Bewertung):
                                                case (0): ?>
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                    <?php break; ?>
                                                <?php case (1): ?>
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                    <?php break; ?>
                                                <?php case (2): ?>
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                    <?php break; ?>
                                                <?php case (3): ?>
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                    <?php break; ?>
                                                <?php case (4): ?>
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/regular/star.svg" alt="platzhalter">
                                                    <?php break; ?>
                                                <?php case (5): ?>
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                <img class="img symbol float-md-left ml-2" src="button/svgs/solid/star.svg" alt="platzhalter">
                                                    <?php break; ?>
                                                <?php endswitch; ?>
                                        </div>
                                    </div>
                                    <div class="row w-100 mb-2 ml-2">
                                        <div class="col m-2">
                                            bewertet am:<br><?php echo e($bew->Zeitpunkt); ?>

                                        </div>
                                        <div class="col border border-dark m-2">
                                            <?php echo e($bew->Bemerkung); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <p>keine Bewertungen</p>
                            <?php endif; ?>
                        <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'Student'): ?>
                        <!--<form action="Detail.php?id=<?php echo e($_GET['id']); ?>" method="post">

                            <fieldset class="border border-dark pl-4">
                                <legend class="ml-4 w-auto">
                                    Mahlzeit bewerten
                                </legend>

                                    <div class="row">
                                        <div class="col-3 text-right m-2">Bewertung: </div>
                                        <div class="col">
                                            <select class="m-2" name="bewertung">
                                                <option>0</option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-3 text-right m-2">Bemerkung: </div>
                                        <div class="col">
                                            <textarea class="m-2" id="bemerkung" name="bemerkung" cols="25" rows="5">Geben Sie eine Bemerkung ein, wenn Sie möchten...</textarea>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-3">

                                        </div>
                                        <div class="col">
                                            <button class="m-2 btn btn-link" type="submit">Bewertung absenden</button>
                                        </div>
                                    </div>
                                    <input type="hidden" name="matrikel" value="3188412">
                                    <input type="hidden" name="benutzerID" value="<?php echo e($_SESSION['benutzerID']); ?>">
                                    <input type="hidden" name="mahlzeitID" value="<?php echo e($_GET['id']); ?>">


                            </fieldset>
                        </form>-->
                        <?php endif; ?>
                    </div>
                    <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'Student'): ?>
                    <div class="tab-pane border-right border-left border-bottom tab_content_size p-2" id="bewertung" role="tabpanel" aria-labelledby="bewertung-tab">

                            <form action="Detail.php?id=<?php echo e($_GET['id']); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <fieldset class="border border-dark pl-4">
                                    <legend class="ml-4 w-auto">
                                        Mahlzeit bewerten
                                    </legend>

                                    <div class="row">
                                        <div class="col-3 text-right m-2">Bewertung: </div>
                                        <div class="col">
                                            <select class="m-2" name="bewertung">
                                                <option>0</option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-3 text-right m-2">Bemerkung: </div>
                                        <div class="col">
                                            <textarea class="m-2" id="bemerkung" name="bemerkung" cols="25" rows="5">Geben Sie eine Bemerkung ein, wenn Sie möchten...</textarea>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-3">

                                        </div>
                                        <div class="col">
                                            <button class="m-2 btn btn-link" type="submit">Bewertung absenden</button>
                                        </div>
                                    </div>
                                    <input type="hidden" name="matrikel" value="3188412">
                                    <input type="hidden" name="benutzerID" value="<?php echo e($_SESSION['benutzerID']); ?>">
                                    <input type="hidden" name="mahlzeitID" value="<?php echo e($_GET['id']); ?>">


                                </fieldset>
                            </form>

                    </div>

                    <?php endif; ?>

                </div>

                <script>
                    $(function () {
                        $('#myTab li:last-child a').tab('show')
                    })
                </script>
            </div>
        </div>


</div>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<?php echo $__env->make('nav.navbarunten', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\DBWT\m4\resources\views/pages/details.blade.php ENDPATH**/ ?>