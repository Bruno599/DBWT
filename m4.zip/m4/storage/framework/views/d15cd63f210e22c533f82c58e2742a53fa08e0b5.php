<footer>
        <div class="container border-top border-dark mb-4 mt-4">
            <div class="row align-items-center mw-100 mt-2">
                <div class="col-3">
                    (c) <?php echo date("Y") ?> DBWT
</div>
<div class="col-1 pr-2 pl-2 text-right">
    <a class="fh_color" href="Login.php">Login</a>
</div>
<div class="col-auto border-left border-dark text-center pr-2 pl-2">
    <a class="fh_color" href="Registration.php">Registrieren</a>
</div>
<div class="col-auto border-left border-dark text-center pr-2 pl-2">
    <?php
    if (basename($_SERVER['PHP_SELF']) == "Zutaten.php") {
        echo "<a>Zutatenliste</a>";
    }
    else {
        echo "<a class=\"fh_color\" href=\"Zutaten.php\">Zutatenliste</a>";
    }
    ?>

</div>
<div class="col-1 border-left border-dark text-center pr-2 pl-2">
    <?php
    if (basename($_SERVER['PHP_SELF']) == "Impressum.php") {
        echo "<a>Impressum</a>";
    }
    else {
        echo "<a class=\"fh_color\" href=\"Impressum.php\">Impressum</a>";
    }

    ?>

</div>
<div class="col text-right">
    <?php
    if(isset($_SESSION['aktive'])){
        echo $_SESSION['user'].' '.$_SESSION['nachname'].' <br>'.$_SESSION['role'];
    }
    ?>
</div>
</div>
</div>
</footer>
<?php /**PATH C:\xampp\htdocs\DBWT\m4\resources\views/navbarunten.blade.php ENDPATH**/ ?>