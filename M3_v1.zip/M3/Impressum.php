<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="3; URL=Start.php">
    <title>Impressum.html</title>
</head>
<body>

</body>
</html>