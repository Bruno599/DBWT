create view Nutzerrollen as
select `B`.`Nummer`                                                                                         AS `Nummer`,
       if(`B`.`Nummer` = `G`.`Nummer`, 'Gast',
          if(`B`.`Nummer` = `M`.`Nummer`, 'Mitarbeiter', if(`B`.`Nummer` = `S`.`Nummer`, 'Student', NULL))) AS `Rolle`
from ((((`db3188412`.`Benutzer` `B` left join `db3188412`.`Gaeste` `G` on (`B`.`Nummer` = `G`.`Nummer`)) left join `db3188412`.`FH Angehoerige` `F A` on (`B`.`Nummer` = `F A`.`Nummer`)) left join `db3188412`.`Mitarbeiter` `M` on (`F A`.`Nummer` = `M`.`Nummer`))
         left join `db3188412`.`Studenten` `S` on (`F A`.`Nummer` = `S`.`Nummer`));

