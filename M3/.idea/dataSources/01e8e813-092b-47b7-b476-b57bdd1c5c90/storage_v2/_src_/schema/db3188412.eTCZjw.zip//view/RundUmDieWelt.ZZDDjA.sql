create definer = s_ds1818s@`%` view RundUmDieWelt as
select `db3188412`.`Kategorien`.`Bezeichnung` AS `Bezeichnung`
from `db3188412`.`Kategorien`
where `db3188412`.`Kategorien`.`hatKategorie` = 4;

